Lawin.Preloader = function(game){


};

Lawin.Preloader.prototype = {

	preload: function(game){


	//player
	game.load.image('enemy', 'img/phaser-dude.png',27,40);
	game.load.image('trees', 'img/girl.png');  
	game.load.image('lawin', 'img/eagle.png',50,50);  
	game.load.image('girl', 'img/lawin.png'); 
	game.load.image('sbutton', 'img/play.png');
	game.load.image('exitbutton', 'img/exit.png');
	game.load.image('aboutbutton', 'img/about.png');
	game.load.image('spots', 'img/bilog.png',25,25); 
	game.load.image('wall1', 'img/wall1.png',820,5);
	game.load.image('wall2', 'img/wall2.png',5,700); 
	game.load.spritesheet('pause','img/p.png',50,50);
	game.load.spritesheet('buttonleft','img/bleft.png',80,80);
	game.load.spritesheet('buttonright','img/bright.png',80,80);
	game.load.spritesheet('buttonup','img/bup.png',80,80);
	game.load.spritesheet('buttondown','img/bdown.png',80,80); 
	},

	
		create: function(game){

		this._fontStyle = { font: "80px Arial", fill: "#FFCCFF", stroke: "#000", strokeThickness: 5, align: "center" };
		// var pausedText = this.add.text(130, 100, "Lawin at Sisiw", this._fontStyle);
		this.stage.backgroundColor = 'feffff';
		sbutton = game.add.button(game.world.centerX - 150,game.world.height - 400,'sbutton',this.startGame,this);
		sbutton.width = 300; sbutton.height = 80;

		exitbutton = game.add.button(game.world.centerX - 150,game.world.height - 300,'exitbutton',this.exitGame,this);
		exitbutton.width = 300; exitbutton.height = 80;

		aboutbutton = game.add.button(game.world.centerX - 150,game.world.height - 200,'aboutbutton',this.aboutGame,this);
		aboutbutton.width = 300; aboutbutton.height = 80;
		},

		startGame:function(game){

			this.state.start('gameplay');

		},


};