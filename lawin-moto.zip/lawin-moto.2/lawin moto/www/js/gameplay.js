Lawin.gameplay = function(game){


};
	var s;
	var left=false;
    var right=false;
    var up= false;
    var down=false;
    var speed = 50;
    var playerSpeed = 100;
    var eagle,chix,eagleSize,speed,direction,new_direction,addNew,score;

Lawin.gameplay.prototype = {


	create: function(game){
	this.stage.backgroundColor = '6B8E99';
	game.physics.startSystem(Phaser.Physics.ARCADE);

	eagleSize = 15;
	score = 0;

	this.generateTrees(game);
	this.generateChix(game);

	eagle = game.add.sprite(game.world.width-700, game.world.height - 630, 'lawin'); //create and position player
    game.physics.arcade.enable(eagle);
    eagle.body.allowGravity = false;
    eagle.body.isCircle = false;  // collision circle
    eagle.body.collideWorldBounds = true;
    eagle.body.allowRotation = true;
    eagle.anchor.set(0.5);
    eagle.body.immovable = true; 
    eagle.width = 50; eagle.height = 45;
    // eagle.body.setSize (50,45,0,0);
    game.camera.follow(eagle);

        textStyle_Key = { font: "bold 14px sans-serif", fill: "#46c0f9", align: "center" };
        textStyle_Value = { font: "bold 18px sans-serif", fill: "#fff", align: "center" };

        // Score.
        game.add.text(590, 30, "Score:",  {font: '20px ComicSans', fill: '#00000'});
        scoreTextValue = game.add.text(670, 30, score.toString(), {font: '20px ComicSans', fill: '#000000'});

	cursors = game.input.keyboard.createCursorKeys();

    buttonup = game.add.button(game.world.width- 650, game.world.height-100, 'buttonup', null, this, 1, 0, 1, 0);
    buttonup.fixedToCamera = true;
    buttonup.alpha = 0.5;
    buttonup.events.onInputOver.add(function(){up=true;});
    buttonup.events.onInputOut.add(function(){up=false;});
    buttonup.events.onInputDown.add(function(){up=true;});
    buttonup.events.onInputUp.add(function(){up=false;});
    
    // buttondown = game.add.button(game.world.width-750, game.world.height-100, 'buttondown', null, this, 0, 1, 0, 1);
    // buttondown.fixedToCamera = true;
    // buttondown.alpha = 0.5
    // buttondown.events.onInputOver.add(function(){down=true;});
    // buttondown.events.onInputOut.add(function(){down=false;});
    // buttondown.events.onInputDown.add(function(){down=true;});
    // buttondown.events.onInputUp.add(function(){down=false;});
    

    buttonright = game.add.button(game.world.width-150, game.world.height-100, 'buttonright', null, this, 1, 0, 1, 0);
    buttonright.fixedToCamera = true;
    buttonright.alpha = 0.5;
    buttonright.events.onInputOver.add(function(){right=true;});
    buttonright.events.onInputOut.add(function(){right=false;});
    buttonright.events.onInputDown.add(function(){right=true;});
    buttonright.events.onInputUp.add(function(){right=false;});
    

    buttonleft = game.add.button(game.world.width-250, game.world.height-100, 'buttonleft', null, this, 0, 1, 0, 1);
    buttonleft.fixedToCamera = true;
    buttonleft.alpha = 0.5;
    buttonleft.events.onInputOver.add(function(){left=true;});
    buttonleft.events.onInputOut.add(function(){left=false;});
    buttonleft.events.onInputDown.add(function(){left=true;});
    buttonleft.events.onInputUp.add(function(){left=false;});

	},

	update: function(game){

		game.physics.arcade.collide(chix);
		game.physics.arcade.overlap(eagle, chix,this.score, null, this);
		game.physics.arcade.collide(trees,eagle,null,this.die,this);
		game.physics.arcade.collide(chix,trees);
    	

    	eagle.body.velocity.x = 0;
    	eagle.body.velocity.y = 0;
    	eagle.body.angularVelocity = 0;

    if (left)
    {
        eagle.body.angularVelocity = -playerSpeed;
    }
    else if (right)
    {
        eagle.body.angularVelocity = playerSpeed;
    }

    if (up)
    {
        eagle.body.velocity.copyFrom(game.physics.arcade.velocityFromAngle(eagle.angle, 300));
    }

	},
    
	generateChix: function(game){

	var randomX = Math.floor(Math.random() * 40 ) * 15,
        randomY = Math.floor(Math.random() * 30 ) * 15;

   	chix = game.add.group();
    chix.enableBody = true;

    for (var i = 0; i < 50; i++)
    {
        s = chix.create(game.rnd.integerInRange(50, 600), game.rnd.integerInRange(200, 600), 'girl');
        s.name = 'chix' + s;
        s.body.collideWorldBounds = true;
        s.body.bounce.setTo(0.8, 0.8);
        //s.body.velocity.setTo(10 + Math.random() * 40, 10 + Math.random() * 40);
        s.body.velocity.x = game.rnd.integerInRange(-200, 200);
		s.body.velocity.y = game.rnd.integerInRange(-200, 200);
    }
        
         // chix = game.add.sprite(randomX, randomY, 'girl');
    },

    generateTrees: function(game){
    	var randomX = Math.floor(Math.random() * 40 ) * 15,
        	randomY = Math.floor(Math.random() * 30 ) * 15;

   	trees = game.add.group();
    trees.enableBody = true;

    for (var i = 0; i < 50; i++)
    {
        var s = trees.create(game.rnd.integerInRange(50, 600), game.rnd.integerInRange(200, 600), 'trees');
        s.body.immovable = true;
    }
    },

    score: function(eagle,chix) {

	score++;

    // Refresh scoreboard.
    scoreTextValue.text = score.toString();
    chix.kill();
    if (score==50){

    	this.win(game);
    }
    },

	die: function(){

		
		this.game.paused = true;
        // add proper informational text
        this._fontStyle = { font: "80px Arial", fill: "#FFF00", stroke: "#100", strokeThickness: 5, align: "center" };
        var pausedText = this.add.text(100, 200, " Game Over \nTap to Retry\n Your Score:"+score, this._fontStyle);
        // set event listener for the user's click/tap the screen
        this.input.onDown.add(function(){
            // remove the pause text
            pausedText.destroy();
            this.state.restart();
            // unpause the game
            this.game.paused = false;
        }, this);
    },

    win: function(){

    	this.game.paused = true;
        // add proper informational text
        this._fontStyle = { font: "80px Arial", fill: "#FFF00", stroke: "#100", strokeThickness: 5, align: "center" };
        var pausedText = this.add.text(100, 200, " You win \nTap to retry", this._fontStyle);
        // set event listener for the user's click/tap the screen
        this.input.onDown.add(function(){
            // remove the pause text
            pausedText.destroy();
            this.state.restart();
            // unpause the game
            this.game.paused = false;
        }, this);
    },
	
};
